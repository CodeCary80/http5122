//LAB 3 - ARRAYS & LOOPS - PART 1


//ARRAY OF FRUITS

var myFruits = ["Apple","Orange","Banana","Bluebarries","Avocado" ]

//OUTPUT ONE FRUIT FROM THE ARRAY IN POPUP BOX

alert("Today's fruit is" + myFruits[0]);