/*window.onload=function(){
    alert("hello World");
}
*/
var myName = "Tianrui Zhu";
console.log(myName)

var myAge = "30";
console.log(myAge)

var daysInYear = 365;
console.log(daysInYear)

var ageMultipliedByDaysInYear = myAge * daysInYear;
console.log(ageMultipliedByDaysInYear)

var myText = "days old… more or less";
console.log(myText)

/*window.onload=function(){
    alert(ageMultipliedByDaysInYear)
}
*/

window.onload=function(){
    alert(myName + "is"+ myAge+ "old…more or less")
}
